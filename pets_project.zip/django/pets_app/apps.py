from django.apps import AppConfig


class PetsAppConfig(AppConfig):
    name = 'pets_app'
